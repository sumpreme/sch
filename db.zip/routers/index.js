const Router = require("express")
const router = new Router;
const userRouter = require("./user-router")

router.use('/user', userRouter)
//router.use('/update', versionController.send)

module.exports = router