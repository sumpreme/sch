const ApiError = require("../exceptions/api-error");
const {UserModel} = require("../models/user-model");
const axios = require("axios");
const {getAccess, getUser} = require("./vk-service")
class UserService {
    async auth(code){
        const data = await getAccess(code);
        return data
    }
    async user(token){
        const data = await getUser(token);
        const user = await UserModel.findOne({where: {vk_id: data.id}})
        if(!user){
            await UserModel.create({vk_id: data.id});
        }
        return data
    }

    async check(token) {
        const data = await getUser(token);
        const user = await UserModel.findOne({where: {vk_id: data.id}})
        if (!user) {
            return
        }
        return data
    }
}
module.exports = new UserService();