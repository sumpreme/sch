const userService = require("../service/user-service");
const ApiError = require("../exceptions/api-error")
const {auth, user, check} = require("../service/user-service")
class UserController{
    async auth (req, res, next){
        try{
            let code = req?.query?.code;
            if(code){
                    const data = await auth(code);
                    await user(data.access_token);
                    const token = data.access_token;
                    res.writeHead(302, {
                        'Location': `http://sch.webirai.ru/auth/?token=${token}`
                        //add other headers here...
                    });
                    res.end();
            }
        }catch (e){
            next(e)
        }
    }
    async check (req, res, next){
        try{
            let token = req?.headers?.authorization.split(" ")[1];
            console.log(token)
            if(token && token !== ""){
                const user = await check(token);
                return res.json({...user})
            }
            return next(ApiError.internal("Ошибка при валидации"));
        }catch (e){
            next(e)
        }
    }

}

module.exports = new UserController()