const Router = require("express")
const userController = require("../controllers/user-controller")
const router = new Router;
const cors = require("cors");


router.get('/auth', userController.auth)
router.get('/check', userController.check)

module.exports = router