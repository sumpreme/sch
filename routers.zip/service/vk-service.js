const axios = require("axios");

class VkService {
    async getAccess(code){
        const {data} = await axios.get(`https://oauth.vk.com/access_token?client_id=51745934&client_secret=tvQCM9Qj5crJnbCabcZf&redirect_uri=http://localhost:5000/api/user/auth&code=`+code)
        return data;
    }
    async getUser(token){
        const {data} = await axios.get(`https://api.vk.com/method/users.get?access_token=${token}&uids=243101827&v=5.81&fields=photo_200`)
        return data.response[0];
    }
}
module.exports = new VkService();